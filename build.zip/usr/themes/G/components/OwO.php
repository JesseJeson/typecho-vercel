<div id="OwO-container">
    <div id="OwO-content">
        <div id="OwO-header">
            <div id="meme-selector">
                <span onclick="slideOwO('tieba')">贴吧</span>
                <span onclick="slideOwO('goutou')">狗头</span>
                <span onclick="slideOwO('yuanshen')">原神</span>
                <span onclick="slideOwO('xhl')">小黄脸</span>
            </div>
            <span id="toggleOwO" onclick="toggleOwO()">收起</span>
        </div>
        <div id="meme-display">
            <h4 id="tieba">贴吧</h4>
            <ul class="meme-section">
                <li class="OwO-item" onclick="Smilies.grin('@(huaji_han)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/huaji_han.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(huaji_mj)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/huaji_mj.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(huaji_djy)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/huaji_djy.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(huaji_pc)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/huaji_pc.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(huaji_shang)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/huaji_shang.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(huaji_xiao)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/huaji_xiao.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(toukan)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/toukan.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(biexiao)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/biexiao.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(hemenjiu)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/hemenjiu.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(chigua2)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/chigua2.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(hehe)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/hehe.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(233)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/233.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(tushe)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/tushe.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(taikaixin)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/taikaixin.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(xiaoyan)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/xiaoyan.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(huaxin)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/huaxin.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(xiaoguai)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/xiaoguai.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(guai)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/guai.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(wuzuixiao)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/wuzuixiao.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(huaji)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/huaji.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(nidongde)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/nidongde.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(bugaoxin)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/bugaoxin.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(nu)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/nu.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(han)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/han.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(heixian)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/heixian.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(lei)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/lei.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(zhenbang)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/zhenbang.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(pen)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/pen.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(jingku)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/jingku.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(yinxian)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/yinxian.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(bishi)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/bishi.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(ku)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/ku.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(a)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/a.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(kuanghan)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/kuanghan.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(what)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/what.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(yiwen)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/yiwen.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(suanshuang)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/suanshuang.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(yamiedie)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/yamiedie.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(weiqu)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/weiqu.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(jingya)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/jingya.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(shuijiao)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/shuijiao.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(xiaoniao)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/xiaoniao.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(wabi)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/wabi.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(tu)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/tu.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(xili)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/xili.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(xiaohonglian)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/xiaohonglian.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(landeli)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/landeli.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(mianqiang)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/mianqiang.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(aixin)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/aixin.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(xinsui)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/xinsui.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(meigui)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/meigui.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(liwu)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/liwu.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(caihong)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/caihong.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(taiyang)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/taiyang.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(xinxinyueliang)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/xinxinyueliang.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(qianbi)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/qianbi.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(chabei)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/chabei.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(dangao)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/dangao.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(damuzhi)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/damuzhi.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(shengli)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/shengli.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(yo)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/yo.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(OK)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/OK.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(shafa)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/shafa.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(shouzhi)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/shouzhi.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(xiangjiao)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/xiangjiao.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(bianbian)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/bianbian.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(yaowan)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/yaowan.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(hlj)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/hlj.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(lazhu)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/lazhu.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(yingyue)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/yingyue.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(dengpao)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/dengpao.png"/></li>
            </ul>
            <h4 id="goutou">狗头</h4>
            <ul class="meme-section">
                <li class="OwO-item" onclick="Smilies.grin('@(chaiquan_love)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/chaiquan_love.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(chaiquan_red_1)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/chaiquan_red_1.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(chaiquan_melon)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/chaiquan_melon.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(chaiquan_mask)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/chaiquan_mask.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(chaiquan_hufen)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/chaiquan_hufen.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(chaiquan_han)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/chaiquan_han.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(chaiquan_gh)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/chaiquan_gh.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(chaiquan_3)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/chaiquan_3.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(chaiquan)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/chaiquan.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(chaiquanbugaoxin)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/chaiquanbugaoxin.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(chaiquanzaijian)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/chaiquanzaijian.png"/></li>
                <li class="OwO-item" onclick="Smilies.grin('@(chaiquanku)');">
                    <img src="<?php echo G::staticUrl('static/img/bq/paopao'); ?>/chaiquanku.png"/></li>
            </ul>
            <h4 id="yuanshen">原神</h4>
            <ul class="meme-section">
                <li class="OwO-item" onclick="Smilies.grin('::ys:安详::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '安详.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:不要啊::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '不要啊.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:交给我吧::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '交给我吧.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:你真幽默::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '你真幽默.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:出货吧::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '出货吧.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:吃惊::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '吃惊.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:咕咕咕::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '咕咕咕.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:哼哼::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '哼哼.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:唔::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '唔.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:大哭::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '大哭.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:小事一桩::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '小事一桩.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:干得漂亮::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '干得漂亮.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:干杯::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '干杯.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:愤怒::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '愤怒.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:拜托::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '拜托.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:救救我::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '救救我.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:睡着了::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '睡着了.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:给我走开::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '给我走开.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:警觉::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '警觉.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:该吃饭了::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '该吃饭了.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:请投币::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '请投币.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:问号::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '问号.png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::ys:黑线::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/ys/', '黑线.png', true); ?>"/></li>
            </ul>
            <h4 id="xhl">小黄脸</h4>
            <ul class="meme-section">
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[doge]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[doge].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[偷笑]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[偷笑].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[傲娇]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[傲娇].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[冷]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[冷].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[吃瓜]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[吃瓜].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[吐]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[吐].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[吓]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[吓].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[呆]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[呆].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[响指]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[响指].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[喜极而泣]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[喜极而泣].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[喜欢]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[喜欢].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[嘘声]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[嘘声].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[囧]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[囧].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[大哭]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[大哭].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[大笑]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[大笑].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[奸笑]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[奸笑].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[妙啊]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[妙啊].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[委屈]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[委屈].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[嫌弃]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[嫌弃].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[害羞]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[害羞].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[尴尬]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[尴尬].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[微笑]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[微笑].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[惊喜]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[惊喜].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[惊讶]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[惊讶].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[打call]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[打call].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[抠鼻]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[抠鼻].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[捂脸]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[捂脸].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[支持]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[支持].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[无语]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[无语].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[滑稽]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[滑稽].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[灵魂出窍]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[灵魂出窍].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[点赞]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[点赞].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[爱心]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[爱心].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[生气]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[生气].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[生病]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[生病].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[画风突变]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[画风突变].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[疼]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[疼].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[福]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[福].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[福到了]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[福到了].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[笑哭]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[笑哭].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[调皮]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[调皮].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[酸了]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[酸了].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[锦鲤]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[锦鲤].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[阴险]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[阴险].png', true); ?>"/></li>
                <li class="OwO-item" onclick="Smilies.grin('::xiaohuanglian:[黑洞]::');">
                    <img src="<?php echo G::MemeUrl('static/img/bq/xiaohuanglian/', '[黑洞].png', true); ?>"/></li>
            </ul>
        </div>
    </div>
</div>