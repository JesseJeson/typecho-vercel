<div id="toc">
    <div id="toc-container">
        <h3>目录</h3>
        <div id="toc-content"></div>
        <span id="toc-close" onclick="toggleToc()">
            <svg t="1636772786776" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2419" width="64" height="64"><path d="M343.104 319.008l-24.128 24.128 168.896 168.896-168.096 168.096 24.128 24.128 168.096-168.096 168.096 168.096 24.128-24.128-168.096-168.096 168.896-168.896-24.128-24.128-168.896 168.896z" p-id="2420"></path></svg>
        </span>
    </div>
</div>