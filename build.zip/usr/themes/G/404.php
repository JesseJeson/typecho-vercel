<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('components/header.php'); ?>
<div id="page404" class="PAP" role="main">
    <h2 style="font-weight: 200; font-size: 4rem; opacity: .3;text-align: center;margin: 15rem 0;">没有找到呢</h2>
</div>
<?php $this->need('components/footer.php'); ?>
